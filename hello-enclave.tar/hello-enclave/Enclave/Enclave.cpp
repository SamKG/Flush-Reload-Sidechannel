#include "Enclave_t.h"

int generate_random_number() {
    ocall_print("Processing random number generation...");
    return 42;
}
